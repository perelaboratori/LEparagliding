

Fixed the error detected by Paweł in the wash-in calculation. Many thanks!!!

This is a rookie mistake, typical of programming with natural "intelligence"... :-) The code uses the wingtip chord value before it has been calculated within the loop, defaulting to 0.0.

The result is a smoother progression of wash-in angles, except at the last rib, where there is a slight jump. All paragliders calculated with automatic wash-in have been computed using this error for years! Cases 1 and 2. However, this error is not critical to the final result and may even have been beneficial in some instances. The wash-in angle creates a distortion that, in principle, reduces aerodynamic efficiency unless rotations around the Z-axis are performed. For the sake of compatibility, we will retain this wash-in calculation feature corresponding to parameter cases 1 and 2. Parameter 0 corresponds to manual wash-in input. We are also creating a new case—parameter 3—that calculates wash-in in exact proportion to the chord (which was the original intention).

Example for Swoop; we need to enter the case "3" as:

--------------------------------------------------------

* Alpha wingtip, parameter, (alpha center) 
	5.0        3         0.0

--------------------------------------------------------

Fixed code:

       do i=1,nribss

       (...)

c      Washin calculus

c      Case 0, set manual washin
       if (kbbb.eq.0) then
       rib(i,8)=rib(i,51)
       end if

c      Case 1. Warning! tip chord rib(nribss,5)=0 until i reaches nribss!
       if (kbbb.eq.1) then
       ribdif=rib(1,5)-rib(i,5)
       ribdim=rib(1,5)-rib(nribss,5)
       rib(i,8)=alpham*ribdif/ribdim
       end if

c      Case 2. tip chord rib(nribss,5)=0 until i reaches nribss!
       if (kbbb.eq.2) then
       ribdif=rib(1,5)-rib(i,5)
       ribdim=rib(1,5)-rib(nribss,5)
       rib(i,8)=(alphat*ribdif/ribdim)+alphac
       end if

       end do

c      Case 3. Use correct ribdim (Introduced 2026-10-12 Thanks to Paweł)
c      Cases 1 and 2 uses rib(nribss,5) until be calculated!
       If (kbbb.eq.3) then
       rib(nribss,5)=rib(nribss,4)-rib(nribss,3)
       do i=1,nribss
       ribdif=rib(1,5)-rib(i,5)
       ribdim=rib(1,5)-rib(nribss,5)
       rib(i,8)=(alphat*ribdif/ribdim)+alphac
       end do
       end if